<?php
/**
* PHP Mikrotik Billing (https://ibnux.github.io/phpmixbill/)
**/

r2(APP_URL.'/index.php?_route=dashboard');
