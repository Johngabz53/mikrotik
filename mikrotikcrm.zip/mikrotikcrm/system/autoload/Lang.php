<?php

/**
 * PHP Mikrotik Billing (https://ibnux.github.io/phpmixbill/)
 **/

class Lang {
    public static function T($var) {
        return Lang($var);
    }
}
