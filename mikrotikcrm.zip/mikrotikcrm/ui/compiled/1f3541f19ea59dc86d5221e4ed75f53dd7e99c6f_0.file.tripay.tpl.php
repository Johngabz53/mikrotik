<?php
/* Smarty version 3.1.39, created on 2023-09-07 22:27:34
  from 'C:\xampp\htdocs\phpmixbill\system\paymentgateway\ui\tripay.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_64f9ebe68bcc48_20425419',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1f3541f19ea59dc86d5221e4ed75f53dd7e99c6f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phpmixbill\\system\\paymentgateway\\ui\\tripay.tpl',
      1 => 1694100399,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:sections/header.tpl' => 1,
    'file:sections/footer.tpl' => 1,
  ),
),false)) {
function content_64f9ebe68bcc48_20425419 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:sections/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<form class="form-horizontal" method="post" role="form" action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
paymentgateway/tripay" >
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel panel-primary panel-hovered panel-stacked mb30">
                <div class="panel-heading">Tripay</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label class="col-md-2 control-label">Kode Merchant</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" id="tripay_merchant" name="tripay_merchant" placeholder="T" value="<?php echo $_smarty_tpl->tpl_vars['_c']->value['tripay_merchant'];?>
">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label">API Key</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" id="tripay_api_key" name="tripay_api_key" value="<?php echo $_smarty_tpl->tpl_vars['_c']->value['tripay_api_key'];?>
">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label">Secret Key</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" id="tripay_secret_key" name="tripay_secret_key" value="<?php echo $_smarty_tpl->tpl_vars['_c']->value['tripay_secret_key'];?>
">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label">Notification URL</label>
                        <div class="col-md-6">
                            <input type="text" readonly class="form-control" onclick="this.select()" value="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
callback/tripay">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label">Channels</label>
                        <div class="col-md-6">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['channels']->value, 'channel');
$_smarty_tpl->tpl_vars['channel']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['channel']->value) {
$_smarty_tpl->tpl_vars['channel']->do_else = false;
?>
                                <label class="checkbox-inline"><input type="checkbox" <?php if (strpos($_smarty_tpl->tpl_vars['_c']->value['tripay_channel'],$_smarty_tpl->tpl_vars['channel']->value['id']) !== false) {?>checked="true"<?php }?> id="tripay_channel" name="tripay_channel[]" value="<?php echo $_smarty_tpl->tpl_vars['channel']->value['id'];?>
"> <?php echo $_smarty_tpl->tpl_vars['channel']->value['name'];?>
</label>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-offset-2 col-lg-10">
                            <button class="btn btn-primary waves-effect waves-light" type="submit"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Save'];?>
</button>
                            <a class="btn btn-info waves-effect waves-light" href="https://tripay.co.id/?ref=TP19304" target="_blank">Daftar Tripay</a>
                        </div>
                    </div>
                        <pre>/ip hotspot walled-garden
add dst-host=tripay.co.id
add dst-host=*.tripay.co.id</pre>
<small id="emailHelp" class="form-text text-muted">Set Telegram Bot to get any error and notification</small>
                </div>
            </div>

        </div>
    </div>
</form>
<?php $_smarty_tpl->_subTemplateRender("file:sections/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
