<?php
/**
* PHP Mikrotik Billing (https://ibnux.github.io/phpmixbill/)
**/

require ('system/boot.php');
App::_run();
